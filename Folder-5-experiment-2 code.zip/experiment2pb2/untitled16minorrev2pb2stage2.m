%% SSIM + PSNR Evaluation for Brain CT Images (Best Alpha Summary Export)
% Author: Nalliah
% Purpose:
% - Loads all CT images from 'no' folder
% - Computes PSNR + SSIM across alpha values
% - Saves original + all alpha-stage enhanced images into separate subfolders
% - Then scans each subfolder, identifies the best alpha enhanced image
% - Saves only the best alpha enhanced images into a new folder (BestAlphaEnhancedImages)

clc; clear; close all;

% --- Folder containing CT images ---
imageFolder ='C:\Users\Dell\Desktop\Scientific report paper\SCIENTIFIC REPORT_PAPER\minor revision response\minorrev2pb2\no';
imageFiles = dir(fullfile(imageFolder, '*.jpg'));  % or '*.png' / '*.dcm'

% --- Count number of images ---
numImages = length(imageFiles);
fprintf('Number of images found in folder: %d\n\n', numImages);

% --- Alpha range and parameters ---
alphaRange = 0.1 : 0.1 : 0.8;
u = 0.1; p = 3; v = 0.5; r = 1;


% --- Main output folder ---
mainOutputFolder = fullfile(pwd, 'AllAlphaEnhancedImages');
if ~exist(mainOutputFolder, 'dir'), mkdir(mainOutputFolder); end

% --- Loop over all images ---
for k = 1:numImages
    % Load baseline CT image
    fileName = fullfile(imageFolder, imageFiles(k).name);
    I1 = imread(fileName);
    if size(I1,3) == 3, I1 = rgb2gray(I1); end
    I1 = im2double(I1);

    % --- Create subfolder for this image ---
    [~, baseName, ~] = fileparts(imageFiles(k).name);
    subFolder = fullfile(mainOutputFolder, baseName);
    if ~exist(subFolder, 'dir'), mkdir(subFolder); end

    % --- Save original image into subfolder ---
    origOutName = fullfile(subFolder, ['orig_' imageFiles(k).name]);
    imwrite(I1, origOutName);

    % Storage for scores
    psnrScores = zeros(size(alphaRange));
    ssimScores = zeros(size(alphaRange));
    enhancedImages = cell(length(alphaRange),1);

 
    % --- Loop over alpha values ---
    for i = 1:length(alphaRange)
        a = alphaRange(i);

        % Build filter kernel
        A = zeros(1,9);
        for n = 1:9
            V = (p^(n-1) * gamma(u + 1)) / gamma(u + n);
            a1 = (v * a) / ((1 + r * (n - 1)) * V);
            A(n) = round(a1, 6);
        end
        M1 = reshape(A, 3, 3);
        matrices{i} = M1;

        % Apply filter
        filteredImage = imfilter(I1, M1, 'replicate');

        % Compute PSNR and SSIM vs original
        psnrScores(i) = psnr(filteredImage, I1);
        [ssimScores(i), ~] = ssim(filteredImage, I1);
  
        % --- Save enhanced image for this alpha into subfolder ---
        enhOutName = fullfile(subFolder, ...
            [sprintf('alpha_%.2f_', a) imageFiles(k).name]);
        imwrite(filteredImage, enhOutName);
    
        % Store enhanced image
        enhancedImages{i} = filteredImage;
    end

    % --- Identify best alpha (highest PSNR) ---
    [maxPSNR, idxBest] = max(psnrScores);
    bestAlpha = alphaRange(idxBest);
    bestEnhanced = enhancedImages{idxBest};

    fprintf('Image: %s | Best Alpha = %.2f | PSNR = %.4f dB | SSIM = %.4f\n', ...
        imageFiles(k).name, bestAlpha, maxPSNR, ssimScores(idxBest));

    % --- Save best enhanced image into summary folder ---
    bestFolder = fullfile(pwd, 'BestAlphaEnhancedImages');
    if ~exist(bestFolder, 'dir'), mkdir(bestFolder); end

    outName = fullfile(bestFolder, ...
        ['best_alpha_' sprintf('%.2f', bestAlpha) '_' imageFiles(k).name]);
    imwrite(bestEnhanced, outName);
end

disp('Best alpha enhanced images saved into BestAlphaEnhancedImages folder.');