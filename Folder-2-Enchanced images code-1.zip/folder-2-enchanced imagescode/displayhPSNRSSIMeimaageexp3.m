%% SSIM + PSNR Evaluation for Brain CT Images (Best Alpha Export + LaTeX + Plots)
% Author: Nalliah
% Purpose: Compare original vs processed CT using SSIM and PSNR, export best results,
% display highest PSNR/SSIM cases with plots, and save figures for LaTeX.

clc; clear; close all;

% --- Folder containing CT images ---
imageFolder = 'C:\Users\Dell\Desktop\Scientific report paper\SCIENTIFIC REPORT_PAPER\matlab code-\brain data set\no';
imageFiles = dir(fullfile(imageFolder, '*.jpg'));  % or '*.png' / '*.dcm'

% --- Count number of images ---
numImages = length(imageFiles);
fprintf('Number of images found in folder: %d\n\n', numImages);

% --- Alpha range and parameters ---
alphaRange = 0.01 : 0.1 : 0.9;
u = 0.1; p = 2.5; v = 0.5; r = 0;

% --- Storage ---
bestAlphaPSNR   = cell(numImages,1);
bestPSNR        = zeros(numImages,1);
bestAlphaSSIM   = cell(numImages,1);
bestSSIM        = zeros(numImages,1);
bestScoresPSNR  = cell(numImages,1);
bestScoresSSIM  = cell(numImages,1);
bestMatrixPSNR  = cell(numImages,1);
bestMatrixSSIM  = cell(numImages,1);

% --- Loop over all images ---
for k = 1:numImages
    % Load baseline CT image
    fileName = fullfile(imageFolder, imageFiles(k).name);
    I1 = imread(fileName);
    if size(I1,3) == 3, I1 = rgb2gray(I1); end
    I1 = im2double(I1);

    % Storage for scores
    psnrScores = zeros(size(alphaRange));
    ssimScores = zeros(size(alphaRange));
    matrices   = cell(length(alphaRange),1);

    % --- Loop over alpha values ---
    for i = 1:length(alphaRange)
        a = alphaRange(i);

        % Build filter kernel
        A = zeros(1,9);
        for n = 1:9
            V  = (p^(n-1) * gamma(u + 1)) / gamma(u + n);
            a1 = (v * a) / ((1 + r * (n - 1)) * V);
            A(n) = round(a1, 6);
        end
        M = reshape(A, 3, 3);
        matrices{i} = M;

        % Apply filter
        filteredImage = imfilter(I1, M, 'replicate');

        % Compute PSNR and SSIM vs original
        psnrScores(i) = psnr(filteredImage, I1);
        ssimScores(i) = ssim(filteredImage, I1);
    end

    % --- Best alpha for this image ---
    [~, idxPSNR] = max(psnrScores);
    [~, idxSSIM] = max(ssimScores);

    bestAlphaPSNR{k}  = sprintf('%.2f', alphaRange(idxPSNR));
    bestPSNR(k)       = psnrScores(idxPSNR);
    bestScoresPSNR{k} = {psnrScores, ssimScores};
    bestMatrixPSNR{k} = matrices{idxPSNR};

    bestAlphaSSIM{k}  = sprintf('%.2f', alphaRange(idxSSIM));
    bestSSIM(k)       = ssimScores(idxSSIM);
    bestScoresSSIM{k} = {psnrScores, ssimScores};
    bestMatrixSSIM{k} = matrices{idxSSIM};
end

% --- Overall bests ---
[overallBestPSNR, idxBestPSNR] = max(bestPSNR);
[overallBestSSIM, idxBestSSIM] = max(bestSSIM);

fprintf('Highest PSNR: %.4f dB (Image: %s, Varpi=%s)\n', ...
    overallBestPSNR, imageFiles(idxBestPSNR).name, bestAlphaPSNR{idxBestPSNR});
disp('Corresponding Matrix M (PSNR case):');
disp(bestMatrixPSNR{idxBestPSNR});

fprintf('Highest SSIM: %.4f (Image: %s, Varpi=%s)\n', ...
    overallBestSSIM, imageFiles(idxBestSSIM).name, bestAlphaSSIM{idxBestSSIM});
disp('Corresponding Matrix M (SSIM case):');
disp(bestMatrixSSIM{idxBestSSIM});

%% --- Display for Highest PSNR and SSIM together ---
figure('Name','Highest PSNR and SSIM Cases','NumberTitle','off');

% Original + Enhanced PSNR
subplot(2,3,1); 
IorigP = im2double(imread(fullfile(imageFolder,imageFiles(idxBestPSNR).name)));
if size(IorigP,3)==3, IorigP = rgb2gray(IorigP); end
imshow(IorigP); title(sprintf('Original PSNR', imageFiles(idxBestPSNR).name));

subplot(2,3,2); 
IenhP  = imfilter(IorigP, bestMatrixPSNR{idxBestPSNR}, 'replicate');
imshow(IenhP); title(sprintf('Enhanced PSNR', overallBestPSNR));

% Original + Enhanced SSIM
subplot(2,3,4); 
IorigS = im2double(imread(fullfile(imageFolder,imageFiles(idxBestSSIM).name)));
if size(IorigS,3)==3, IorigS = rgb2gray(IorigS); end
imshow(IorigS); title(sprintf('Original SSIM ', imageFiles(idxBestSSIM).name));

subplot(2,3,5); 
IenhS  = imfilter(IorigS, bestMatrixSSIM{idxBestSSIM}, 'replicate');
imshow(IenhS); title(sprintf('Enhanced SSIM )', overallBestSSIM));

% Combined plot (PSNR+SSIM curves for both best cases)
subplot(2,3,[3,6]);
yyaxis left; plot(alphaRange, bestScoresPSNR{idxBestPSNR}{1}, '-o','LineWidth',1.5); ylabel('PSNR (dB)');
yyaxis right; plot(alphaRange, bestScoresSSIM{idxBestSSIM}{2}, '-s','LineWidth',1.5); ylabel('SSIM');
xlabel('Varpi'); title('PSNR + SSIM vs Varpi'); grid on; legend('PSNR (best case)','SSIM (best case)');

% Save figure for LaTeX
combinedFigFile = 'highest_cases_combined exp3.png';
saveas(gcf, combinedFigFile);

%% --- Export LaTeX file with only highest cases ---
fid5 = fopen('best_cases_highestonly exp3.tex','w');

fprintf(fid5, '\\begin{table}[ht]\\n');
fprintf(fid5, '\\centering\\n');
fprintf(fid5, '\\caption{Highest PSNR and SSIM Values}\\n');
fprintf(fid5, '\\begin{tabular}{|c|c|c|c|}\\n');
fprintf(fid5, '\\hline\\n');
fprintf(fid5, '\\textbf{Case} & \\textbf{Image} & \\textbf{Best $\\\\varpi$} & \\textbf{Value} \\\\\\n');
fprintf(fid5, '\\hline\\n');

fprintf(fid5, 'Highest PSNR & %s & %s & %.4f dB \\\\\\n', ...
    imageFiles(idxBestPSNR).name, bestAlphaPSNR{idxBestPSNR}, overallBestPSNR);

fprintf(fid5, 'Highest SSIM & %s & %s & %.4f \\\\\\n', ...
    imageFiles(idxBestSSIM).name, bestAlphaSSIM{idxBestSSIM}, overallBestSSIM);

fprintf(fid5, '\\hline\\n');
fprintf(fid5, '\\end{tabular}\\n');
fprintf(fid5, '\\end{table}\\n\\n');

% Attach combined figure
fprintf(fid5, '\\begin{figure}[ht]\\n');
fprintf(fid5, '\\centering\\n');
fprintf(fid5, '\\includegraphics[width=0.95\\textwidth]{%s}\\n', strrep(combinedFigFile,'\\','/'));
fprintf(fid5, '\\caption{Highest PSNR and SSIM cases: Original, Enhanced images, and combined PSNR+SSIM plot.}\\n');
fprintf(fid5, '\\end{figure}\\n');

fclose(fid5);

disp('LaTeX file saved as best_cases_highestonly exp3.tex with only highest PSNR/SSIM values and combined plot.');

%% --- Export LaTeX file with only highest cases + matrices ---
fid5 = fopen('best_cases_highestonly exp3.tex','w');

fprintf(fid5, '\\begin{table}[ht]\\n');
fprintf(fid5, '\\centering\\n');
fprintf(fid5, '\\caption{Highest PSNR and SSIM Values with Corresponding Matrix $M$}\\n');
fprintf(fid5, '\\begin{tabular}{|c|c|c|c|}\\n');
fprintf(fid5, '\\hline\\n');
fprintf(fid5, '\\textbf{Case} & \\textbf{Image} & \\textbf{Best $\\\\varpi$} & \\textbf{Value} \\\\\\n');
fprintf(fid5, '\\hline\\n');

fprintf(fid5, 'Highest PSNR & %s & %s & %.4f dB \\\\\\n', ...
    imageFiles(idxBestPSNR).name, bestAlphaPSNR{idxBestPSNR}, overallBestPSNR);

fprintf(fid5, 'Highest SSIM & %s & %s & %.4f \\\\\\n', ...
    imageFiles(idxBestSSIM).name, bestAlphaSSIM{idxBestSSIM}, overallBestSSIM);

fprintf(fid5, '\\hline\\n');
fprintf(fid5, '\\end{tabular}\\n');
fprintf(fid5, '\\end{table}\\n\\n');

% --- Matrix M for PSNR case ---
fprintf(fid5, '\\[ M_{PSNR} = \\begin{bmatrix}\\n');
Mpsnr = bestMatrixPSNR{idxBestPSNR};
for r = 1:size(Mpsnr,1)
    fprintf(fid5, ' %.6f & %.6f & %.6f \\\\\\n', Mpsnr(r,:));
end
fprintf(fid5, '\\end{bmatrix} \\]\\n\\n');

%% --- Export LaTeX file with only highest cases ---
fid5 = fopen('best_cases_highestonly exp3.tex','w');

fprintf(fid5, '\\begin{table}[ht]\n');
fprintf(fid5, '\\centering\n');
fprintf(fid5, '\\caption{Highest PSNR and SSIM Values}\n');
fprintf(fid5, '\\begin{tabular}{|c|c|c|c|}\n');
fprintf(fid5, '\\hline\n');
fprintf(fid5, '\\textbf{Case} & \\textbf{Image} & \\textbf{Best }$\\varpi$ & \\textbf{Value} \\\\\n');
fprintf(fid5, '\\hline\n');

fprintf(fid5, 'Highest PSNR & %s & %s & %.4f dB \\\\\n', ...
    imageFiles(idxBestPSNR).name, bestAlphaPSNR{idxBestPSNR}, overallBestPSNR);

fprintf(fid5, 'Highest SSIM & %s & %s & %.4f \\\\\n', ...
    imageFiles(idxBestSSIM).name, bestAlphaSSIM{idxBestSSIM}, overallBestSSIM);

fprintf(fid5, '\\hline\n');
fprintf(fid5, '\\end{tabular}\n');
fprintf(fid5, '\\end{table}\n\n');

% Attach combined figure
fprintf(fid5, '\\begin{figure}[ht]\n');
fprintf(fid5, '\\centering\n');
fprintf(fid5, '\\includegraphics[width=0.95\\textwidth]{%s}\n', strrep(combinedFigFile,'\\','/'));
fprintf(fid5, '\\caption{Highest PSNR and SSIM cases: Original, Enhanced images, and combined PSNR+SSIM plot.}\n');
fprintf(fid5, '\\end{figure}\n');

fclose(fid5);

disp('LaTeX file saved as best_cases_highestonly exp3.tex with only highest PSNR/SSIM values and combined plot.');

%% --- Export LaTeX file with highest PSNR/SSIM values and embedded matrices ---
fid5 = fopen('best_cases_highestonly_withM.tex','w');

fprintf(fid5, '\\begin{table}[ht]\n');
fprintf(fid5, '\\centering\n');
fprintf(fid5, '\\caption{Highest PSNR and SSIM Values with Corresponding Matrix $M$}\n');
fprintf(fid5, '\\begin{tabular}{|c|c|c|c|}\n');
fprintf(fid5, '\\hline\n');
fprintf(fid5, '\\textbf{Case} & \\textbf{Image} & \\textbf{Best }$\\varpi$ & \\textbf{Value} \\\\\n');
fprintf(fid5, '\\hline\n');

% --- Highest PSNR row ---
fprintf(fid5, 'Highest PSNR & %s & %s & %.4f dB \\\\\n', ...
    imageFiles(idxBestPSNR).name, bestAlphaPSNR{idxBestPSNR}, overallBestPSNR);
fprintf(fid5, '\\multicolumn{4}{|c|}{$M_{PSNR} = \\begin{bmatrix}\n');
Mpsnr = bestMatrixPSNR{idxBestPSNR};
for r = 1:size(Mpsnr,1)
    fprintf(fid5, '%.6f & %.6f & %.6f \\\\\n', Mpsnr(r,:));
end
fprintf(fid5, '\\end{bmatrix}$} \\\\\n');
fprintf(fid5, '\\hline\n');

% --- Highest SSIM row ---
fprintf(fid5, 'Highest SSIM & %s & %s & %.4f \\\\\n', ...
    imageFiles(idxBestSSIM).name, bestAlphaSSIM{idxBestSSIM}, overallBestSSIM);
fprintf(fid5, '\\multicolumn{4}{|c|}{$M_{SSIM} = \\begin{bmatrix}\n');
Mssim = bestMatrixSSIM{idxBestSSIM};
for r = 1:size(Mssim,1)
    fprintf(fid5, '%.6f & %.6f & %.6f \\\\\n', Mssim(r,:));
end
fprintf(fid5, '\\end{bmatrix}$} \\\\\n');
fprintf(fid5, '\\hline\n');

fprintf(fid5, '\\end{tabular}\n');
fprintf(fid5, '\\end{table}\n\n');

% --- Attach combined figure ---
fprintf(fid5, '\\begin{figure}[ht]\n');
fprintf(fid5, '\\centering\n');
fprintf(fid5, '\\includegraphics[width=0.95\\textwidth]{%s}\n', strrep(combinedFigFile,'\\','/'));
fprintf(fid5, '\\caption{Highest PSNR and SSIM cases: Original, Enhanced images, and combined PSNR+SSIM plot.}\n');
fprintf(fid5, '\\end{figure}\n');

fclose(fid5);

disp('LaTeX file saved as best_cases_highestonly_withM.tex with embedded matrices and combined plot.');