%% Highest PSNR + SSIM Evaluation with Combined Display + Matrix Export
% Author: Nalliah
% Purpose: Display highest PSNR and SSIM cases with input image, enhanced image,
% PSNR+SSIM plots, and corresponding filter matrix M. Export results to LaTeX.

clc; clear; close all;

% --- Folder containing CT images ---
imageFolder = 'C:\Users\Dell\Desktop\Scientific report paper\SCIENTIFIC REPORT_PAPER\matlab code-\brain data set\no'; 
imageFiles = dir(fullfile(imageFolder, '*.jpg'));  % or '*.png' / '*.dcm'

% --- Count number of images ---
numImages = length(imageFiles);
fprintf('Number of images found in folder: %d\n\n', numImages);

% --- Alpha range and parameters ---
alphaRange = 0.71 : 0.01 : 0.95;
u = 0.1; p = 2.8; w = 1; r = 0.8;

% --- Storage ---
bestAlphaPSNR = cell(numImages,1);
bestPSNR = zeros(numImages,1);
bestAlphaSSIM = cell(numImages,1);
bestSSIM = zeros(numImages,1);
bestFilteredPSNR = cell(numImages,1);
bestFilteredSSIM = cell(numImages,1);
bestScoresPSNR = cell(numImages,1);
bestScoresSSIM = cell(numImages,1);
bestMatrixPSNR = cell(numImages,1);
bestMatrixSSIM = cell(numImages,1);

% --- Loop over all images ---
for k = 1:numImages
    % Load baseline CT image
    fileName = fullfile(imageFolder, imageFiles(k).name);
    I1 = imread(fileName);
    if size(I1,3) == 3, I1 = rgb2gray(I1); end
    I1 = im2double(I1);

    % Storage for scores
    psnrScores = zeros(size(alphaRange));
    ssimScores = zeros(size(alphaRange));
    filteredImages = cell(length(alphaRange),1);
    matrices = cell(length(alphaRange),1);

    % --- Loop over alpha values ---
    for i = 1:length(alphaRange)
        a = alphaRange(i);

        % Build filter kernel
        A = zeros(1,9);
        for n = 1:9
            V = (p^(n-1) * gamma(u + 1)) / gamma(u + n);
            a1 = ((1 - a) * w) / ((1 + r * (n - 1)) * V);
            A(n) = round(a1, 6);
        end
        M = reshape(A, 3, 3);
        matrices{i} = M;

        % Apply filter
        filteredImage = imfilter(I1, M, 'replicate');
        filteredImages{i} = filteredImage;

        % Compute PSNR and SSIM vs original
        psnrScores(i) = psnr(filteredImage, I1);
        [ssimScores(i), ~] = ssim(filteredImage, I1);
    end

    % --- Best alpha for this image ---
    [~, idxPSNR] = max(psnrScores);
    [~, idxSSIM] = max(ssimScores);

    bestAlphaPSNR{k} = sprintf('%.2f', alphaRange(idxPSNR));
    bestPSNR(k) = psnrScores(idxPSNR);
    bestFilteredPSNR{k} = filteredImages{idxPSNR};
    bestScoresPSNR{k} = {psnrScores, ssimScores};
    bestMatrixPSNR{k} = matrices{idxPSNR};

    bestAlphaSSIM{k} = sprintf('%.2f', alphaRange(idxSSIM));
    bestSSIM(k) = ssimScores(idxSSIM);
    bestFilteredSSIM{k} = filteredImages{idxSSIM};
    bestScoresSSIM{k} = {psnrScores, ssimScores};
    bestMatrixSSIM{k} = matrices{idxSSIM};
end

% --- Find overall highest PSNR and SSIM ---
[overallBestPSNR, idxBestPSNR] = max(bestPSNR);
[overallBestSSIM, idxBestSSIM] = max(bestSSIM);

fprintf('Highest PSNR: %.4f dB (Image: %s, Alpha=%s)\n', ...
    overallBestPSNR, imageFiles(idxBestPSNR).name, bestAlphaPSNR{idxBestPSNR});
disp('Corresponding Matrix M (PSNR case):');
disp(bestMatrixPSNR{idxBestPSNR});

fprintf('Highest SSIM: %.4f (Image: %s, Alpha=%s)\n', ...
    overallBestSSIM, imageFiles(idxBestSSIM).name, bestAlphaSSIM{idxBestSSIM});
disp('Corresponding Matrix M (SSIM case):');
disp(bestMatrixSSIM{idxBestSSIM});

%% --- Combined Display for Highest PSNR ---
figure('Name','Highest PSNR Case','NumberTitle','off');
subplot(1,3,1); imshow(im2double(imread(fullfile(imageFolder,imageFiles(idxBestPSNR).name))));
title(sprintf('Original (%s)', imageFiles(idxBestPSNR).name));
subplot(1,3,2); imshow(bestFilteredPSNR{idxBestPSNR});
title(sprintf('Enhanced', bestAlphaPSNR{idxBestPSNR}, overallBestPSNR));
subplot(1,3,3);
yyaxis left
plot(alphaRange, bestScoresPSNR{idxBestPSNR}{1}, '-o','LineWidth',1.5);
ylabel('PSNR (dB)');
yyaxis right
plot(alphaRange, bestScoresPSNR{idxBestPSNR}{2}, '-s','LineWidth',1.5);
ylabel('SSIM');
xlabel('Alpha'); title('PSNR + SSIM vs Alpha');
grid on; legend('PSNR','SSIM');

%% --- Combined Display for Highest SSIM ---
figure('Name','Highest SSIM Case','NumberTitle','off');
subplot(1,3,1); imshow(im2double(imread(fullfile(imageFolder,imageFiles(idxBestSSIM).name))));
title(sprintf('Original (%s)', imageFiles(idxBestSSIM).name));
subplot(1,3,2); imshow(bestFilteredSSIM{idxBestSSIM});
title(sprintf('Enhanced', bestAlphaSSIM{idxBestSSIM}, overallBestSSIM));
subplot(1,3,3);
yyaxis left
plot(alphaRange, bestScoresSSIM{idxBestSSIM}{1}, '-o','LineWidth',1.5);
ylabel('PSNR (dB)');
yyaxis right
plot(alphaRange, bestScoresSSIM{idxBestSSIM}{2}, '-s','LineWidth',1.5);
ylabel('SSIM');
xlabel('Alpha'); title('PSNR + SSIM vs Alpha');
grid on; legend('PSNR','SSIM');

%% --- Export to LaTeX file ---
fid = fopen('best_cases_resultsdisplayimageexp1.tex','w');
fprintf(fid, '\\begin{table}[ht]\\n');
fprintf(fid, '\\centering\\n');
fprintf(fid, '\\caption{Highest PSNR and SSIM Cases with Corresponding Matrix M}\\n');
fprintf(fid, '\\begin{tabular}{|c|c|c|c|}\\n');
fprintf(fid, '\\hline\\n');
fprintf(fid, '\\textbf{Case} & \\textbf{Image} & \\textbf{Best α} & \\textbf{Matrix M (3x3)} \\\\\\n');
fprintf(fid, '\\hline\\n');

% PSNR case
fprintf(fid, 'Highest PSNR (%.4f dB) & %s & %s & ', overallBestPSNR, imageFiles(idxBestPSNR).name, bestAlphaPSNR{idxBestPSNR});
fprintf(fid, '$\\begin{bmatrix} %.4f & %.4f & %.4f \\\\ %.4f & %.4f & %.4f \\\\ %.4f & %.4f & %.4f \\end{bmatrix}$ \\\\\\n', bestMatrixPSNR{idxBestPSNR}');

% SSIM case
fprintf(fid, 'Highest SSIM (%.4f) & %s & %s & ', overallBestSSIM, imageFiles(idxBestSSIM).name, bestAlphaSSIM{idxBestSSIM});
fprintf(fid, '$\\begin{bmatrix} %.4f & %.4f & %.4f \\\\ %.4f & %.4f & %.4f \\\\ %.4f & %.4f & %.4f \\end{bmatrix}$ \\\\\\n', bestMatrixSSIM{idxBestSSIM}');

fprintf(fid, '\\hline\\n');
fprintf(fid, '\\end{tabular}\\n');
fprintf(fid, '\\end{table}\\n');
fclose(fid);

disp('LaTeX file saved as best_cases_resultsdisplayimageexp1.tex with highest PSNR/SSIM cases and their M matrices.');

% --- Save Figures for LaTeX ---
psnrFigFile = 'highest_psnr_case.png';
ssimFigFile = 'highest_ssim_case.png';

hPSNR = findobj('Name','Highest PSNR Case');
hSSIM = findobj('Name','Highest SSIM Case');

if isempty(hPSNR) || isempty(hSSIM)
    error('Figures not found. Ensure figures are created before saving.');
end

saveas(hPSNR, psnrFigFile);
saveas(hSSIM, ssimFigFile);

% --- Export to LaTeX file with table and plots ---
outFile = 'best_cases_resultsdisplayimageexp12.tex';
[fid4, msg] = fopen(outFile, 'w');
if fid4 == -1
    error('Failed to open %s for writing: %s', outFile, msg);
end

% Table
fprintf(fid4, '\\begin{table}[ht]\n\\centering\n');
fprintf(fid4, '\\caption{Highest PSNR and SSIM Cases with Corresponding Matrix $M$}\n');
fprintf(fid4, '\\begin{tabular}{|c|c|c|c|}\n\\hline\n');
fprintf(fid4, '\\textbf{Case} & \\textbf{Image} & \\textbf{Best $\\alpha$} & \\textbf{Matrix $M$ (3x3)} \\\\\n\\hline\n');

Mpsnr = bestMatrixPSNR{idxBestPSNR};
fprintf(fid4, 'Highest PSNR (%.4f dB) & %s & %s & ', overallBestPSNR, imageFiles(idxBestPSNR).name, bestAlphaPSNR{idxBestPSNR});
fprintf(fid4, '$\\begin{bmatrix} %.4f & %.4f & %.4f \\\\ %.4f & %.4f & %.4f \\\\ %.4f & %.4f & %.4f \\end{bmatrix}$ \\\\\n', Mpsnr(:));

Mssim = bestMatrixSSIM{idxBestSSIM};
fprintf(fid4, 'Highest SSIM (%.4f) & %s & %s & ', overallBestSSIM, imageFiles(idxBestSSIM).name, bestAlphaSSIM{idxBestSSIM});
fprintf(fid4, '$\\begin{bmatrix} %.4f & %.4f & %.4f \\\\ %.4f & %.4f & %.4f \\\\ %.4f & %.4f & %.4f \\end{bmatrix}$ \\\\\n', Mssim(:));

fprintf(fid4, '\\hline\n\\end{tabular}\n\\end{table}\n\n');

% Figures
fprintf(fid4, '\\begin{figure}[ht]\n\\centering\n');
fprintf(fid4, '\\includegraphics[width=0.9\\textwidth]{%s}\n', psnrFigFile);
fprintf(fid4, '\\caption{Figure~\\ref{fig:psnr} Highest PSNR case: Original, Enhanced image, and PSNR+SSIM plot}\n');
fprintf(fid4, '\\label{fig:psnr}\n\\end{figure}\n\n');

fprintf(fid4, '\\begin{figure}[ht]\n\\centering\n');
fprintf(fid4, '\\includegraphics[width=0.9\\textwidth]{%s}\n', ssimFigFile);
fprintf(fid4, '\\caption{Figure~\\ref{fig:ssim} Highest SSIM case: Original, Enhanced image, and PSNR+SSIM plot}\n');
fprintf(fid4, '\\label{fig:ssim}\n\\end{figure}\n');

status = fclose(fid4);
if status ~= 0
    warning('Failed to close %s properly.', outFile);
end

disp(['LaTeX file saved as ', outFile, ' with matrices and attached plots.']);