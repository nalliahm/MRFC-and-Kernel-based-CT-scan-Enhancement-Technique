%% SSIM + PSNR Evaluation for Brain CT Images (Best Alpha Export + LaTeX + Plots)
% Author: Nalliah
% Purpose: Compare original vs processed CT using SSIM and PSNR, export best results,
% display highest PSNR/SSIM cases with plots, and save figures for LaTeX.

clc; clear; close all;

% --- Folder containing CT images ---
imageFolder = 'C:\Users\Dell\Desktop\Scientific report paper\SCIENTIFIC REPORT_PAPER\matlab code-\brain data set\no'; 
imageFiles = dir(fullfile(imageFolder, '*.jpg'));  % or '*.png' / '*.dcm'

% --- Count number of images ---
numImages = length(imageFiles);
fprintf('Number of images found in folder: %d\n\n', numImages);

% --- Alpha range and parameters ---
alphaRange = 0.1 : 0.1 : 0.8;
u = 0.1; p = 3; v = 0.5; r = 1;

% --- Storage ---
bestAlphaPSNR = cell(numImages,1);
bestPSNR = zeros(numImages,1);
bestAlphaSSIM = cell(numImages,1);
bestSSIM = zeros(numImages,1);
bestMatrixPSNR = cell(numImages,1);
bestMatrixSSIM = cell(numImages,1);

% --- Loop over all images ---
for k = 1:numImages
    % Load baseline CT image
    fileName = fullfile(imageFolder, imageFiles(k).name);
    I1 = imread(fileName);
    if size(I1,3) == 3, I1 = rgb2gray(I1); end
    I1 = im2double(I1);

    % Storage for scores
    psnrScores = zeros(size(alphaRange));
    ssimScores = zeros(size(alphaRange));
    matrices = cell(length(alphaRange),1);

    % --- Loop over alpha values ---
    for i = 1:length(alphaRange)
        a = alphaRange(i);

        % Build filter kernel
        A = zeros(1,9);
        for n = 1:9
            V = (p^(n-1) * gamma(u + 1)) / gamma(u + n);
            a1 = (v * a) / ((1 + r * (n - 1)) * V);
            A(n) = round(a1, 6);
        end
        M = reshape(A, 3, 3);
        matrices{i} = M;

        % Apply filter
        filteredImage = imfilter(I1, M, 'replicate');

        % Compute PSNR and SSIM vs original
        psnrScores(i) = psnr(filteredImage, I1);
        [ssimScores(i), ~] = ssim(filteredImage, I1);
    end

    % --- Best alpha for this image ---
    [~, idxPSNR] = max(psnrScores);
    [~, idxSSIM] = max(ssimScores);

    bestAlphaPSNR{k} = sprintf('%.2f', alphaRange(idxPSNR));
    bestPSNR(k) = psnrScores(idxPSNR);
    bestMatrixPSNR{k} = matrices{idxPSNR};

    bestAlphaSSIM{k} = sprintf('%.2f', alphaRange(idxSSIM));
    bestSSIM(k) = ssimScores(idxSSIM);
    bestMatrixSSIM{k} = matrices{idxSSIM};
end

% --- Find overall highest PSNR and SSIM ---
[overallBestPSNR, idxBestPSNR] = max(bestPSNR);
[overallBestSSIM, idxBestSSIM] = max(bestSSIM);

% --- Compute Mean ± Standard Deviation across dataset ---
meanPSNR = mean(bestPSNR);
stdPSNR  = std(bestPSNR);
meanSSIM = mean(bestSSIM);
stdSSIM  = std(bestSSIM);

fprintf('PSNR (mean ± SD): %.4f ± %.4f dB\n', meanPSNR, stdPSNR);
fprintf('SSIM (mean ± SD): %.4f ± %.4f\n', meanSSIM, stdSSIM);

% --- Save Figures for LaTeX ---
psnrFigFile = 'highest_psnr_case_exp22.png';
ssimFigFile = 'highest_ssim_case_exp22.png';

hPSNR = findobj('Type','figure','Name','Highest PSNR Case exp2');
hSSIM = findobj('Type','figure','Name','Highest SSIM Case exp2');

if ~isempty(hPSNR), saveas(hPSNR, psnrFigFile); end
if ~isempty(hSSIM), saveas(hSSIM, ssimFigFile); end

% --- Export LaTeX table with Mean ± SD column ---
fid5 = fopen('best_cases_resultsdisplayimageexp22.tex','w');

fprintf(fid5, '\\begin{table}[ht]\\n');
fprintf(fid5, '\\centering\\n');
fprintf(fid5, '\\caption{Highest PSNR and SSIM Cases with Corresponding Matrix $M$ and Mean $\\pm$ SD}\\n');
fprintf(fid5, '\\begin{tabular}{|c|c|c|c|c|}\\n');
fprintf(fid5, '\\hline\\n');
fprintf(fid5, '\\textbf{Case} & \\textbf{Image} & \\textbf{Best Varpi} & \\textbf{Matrix $M$ (3x3)} & \\textbf{Mean $\\pm$ SD} \\\\\\n');
fprintf(fid5, '\\hline\\n');

% PSNR case row
Mpsnr = bestMatrixPSNR{idxBestPSNR};
fprintf(fid5, 'Highest PSNR (%.4f dB) & %s & %s & ', overallBestPSNR, imageFiles(idxBestPSNR).name, bestAlphaPSNR{idxBestPSNR});
fprintf(fid5, '$\\begin{bmatrix} %.4f & %.4f & %.4f \\\\ %.4f & %.4f & %.4f \\\\ %.4f & %.4f & %.4f \\end{bmatrix}$ & ', ...
    Mpsnr(1,1), Mpsnr(1,2), Mpsnr(1,3), Mpsnr(2,1), Mpsnr(2,2), Mpsnr(2,3), Mpsnr(3,1), Mpsnr(3,2), Mpsnr(3,3));
fprintf(fid5, '%.4f $\\pm$ %.4f dB \\\\\\n', meanPSNR, stdPSNR);

% SSIM case row
Mssim = bestMatrixSSIM{idxBestSSIM};
fprintf(fid5, 'Highest SSIM (%.4f) & %s & %s & ', overallBestSSIM, imageFiles(idxBestSSIM).name, bestAlphaSSIM{idxBestSSIM});
fprintf(fid5, '$\\begin{bmatrix} %.4f & %.4f & %.4f \\\\ %.4f & %.4f & %.4f \\\\ %.4f & %.4f & %.4f \\end{bmatrix}$ & ', ...
    Mssim(1,1), Mssim(1,2), Mssim(1,3), Mssim(2,1), Mssim(2,2), Mssim(2,3), Mssim(3,1), Mssim(3,2), Mssim(3,3));
fprintf(fid5, '%.4f $\\pm$ %.4f \\\\\\n', meanSSIM, stdSSIM);

fprintf(fid5, '\\hline\\n');
fprintf(fid5, '\\end{tabular}\\n');
fprintf(fid5, '\\end{table}\\n\\n');

% Attach saved plots
fprintf(fid5, '\\begin{figure}[ht]\\n');
fprintf(fid5, '\\centering\\n');
fprintf(fid5, '\\includegraphics[width=0.9\\textwidth]{%s}\\n', psnrFigFile);
fprintf(fid5, '\\caption{Highest PSNR case: Original, Enhanced image, and PSNR+SSIM plot}\\n');
fprintf(fid5, '\\end{figure}\\n\\n');

fprintf(fid5, '\\begin{figure}[ht]\\n');
fprintf(fid5, '\\centering\\n');
fprintf(fid5, '\\includegraphics[width=0.9\\textwidth]{%s}\\n', ssimFigFile);
fprintf(fid5, '\\caption{Highest SSIM case: Original, Enhanced image, and PSNR+SSIM plot}\\n');
fprintf(fid5, '\\end{figure}\\n');

fclose(fid5);

disp('LaTeX file saved as best_cases_resultsdisplayimageexp22.tex with matrices, mean ± SD column, and attached plots.');