%% SSIM + PSNR Evaluation for Brain CT Images (Best Alpha Only Export + Longtable + Image Count + Plots)
% Author: Nalliah
% Purpose: Compare original vs processed CT using SSIM and PSNR for each alpha
% across all images in a folder, display best alpha results in console,
% export them into LaTeX longtable (multipage support), and plot curves.

clc; clear; close all;

% --- Folder containing CT images ---
imageFolder = 'C:\Users\Dell\Desktop\Scientific report paper\SCIENTIFIC REPORT_PAPER\matlab code-\brain data set\no';   % <-- change to your folder path
imageFiles = dir(fullfile(imageFolder, '*.jpg'));  % or '*.png' / '*.dcm'

% --- Count number of images ---
numImages = length(imageFiles);
fprintf('Number of images found in folder: %d\n\n', numImages);

% --- Alpha range and parameters ---
alphaRange = 0.1 : 0.1 : 0.8;
u = 0.1; p = 3; v = 0.5; r = 1;

% --- Storage for summary table ---
bestAlphaPSNR = cell(numImages,1);
bestPSNR = zeros(numImages,1);
bestAlphaSSIM = cell(numImages,1);
bestSSIM = zeros(numImages,1);

% --- Loop over all images ---
for k = 1:numImages
    % Load baseline CT image
    fileName = fullfile(imageFolder, imageFiles(k).name);
    I1 = imread(fileName);
    if size(I1,3) == 3, I1 = rgb2gray(I1); end
    I1 = im2double(I1);

    % Storage for scores
    psnrScores = zeros(size(alphaRange));
    ssimScores = zeros(size(alphaRange));

    % --- Loop over alpha values ---
    for i = 1:length(alphaRange)
        a = alphaRange(i);

        % Build filter kernel
        A = zeros(1,9);
        for n = 1:9
            V = (p^(n-1) * gamma(u + 1)) / gamma(u + n);
            a1 = (v * a) / ((1 + r * (n - 1)) * V);
            A(n) = round(a1, 6);
        end
        M = reshape(A, 3, 3);

        % Apply filter
        filteredImage = imfilter(I1, M, 'replicate');

        % Compute PSNR and SSIM vs original
        psnrScores(i) = psnr(filteredImage, I1);
        [ssimScores(i), ~] = ssim(filteredImage, I1);
    end

    % --- Prediction: best alpha for this image ---
    [~, idxPSNR] = max(psnrScores);
    [~, idxSSIM] = max(ssimScores);

    bestAlphaPSNR{k} = sprintf('%.2f', alphaRange(idxPSNR));
    bestPSNR(k) = psnrScores(idxPSNR);
    bestAlphaSSIM{k} = sprintf('%.2f', alphaRange(idxSSIM));
    bestSSIM(k) = ssimScores(idxSSIM);

    % --- Display results in MATLAB console ---
  %  fprintf('Image %d/%d: %s\n', k, numImages, imageFiles(k).name);
   % fprintf('   Best varpi (PSNR) = %s with PSNR = %.4f dB\n', bestAlphaPSNR{k}, bestPSNR(k));
    %fprintf('   Best varpi (SSIM) = %s with SSIM = %.4f\n\n', bestAlphaSSIM{k}, bestSSIM(k));

    % --- Plot results for this image ---
    %figure('Name', imageFiles(k).name, 'NumberTitle', 'off');

    % Plot 1: PSNR vs Alpha
    %subplot(1,3,1);
    %plot(alphaRange, psnrScores, '-o','LineWidth',1.5);
    %xlabel('Varpi'); ylabel('PSNR (dB)');
    %title('PSNR vs varpi'); grid on;

    % Plot 2: SSIM vs Alpha
    %subplot(1,3,2);
    %plot(alphaRange, ssimScores, '-s','LineWidth',1.5);
    %xlabel('Varpi'); ylabel('SSIM');
    %title('SSIM vs varpi'); grid on;

    % Plot 3: Combined PSNR + SSIM vs Alpha
    %subplot(1,3,3);
    %yyaxis left
    %plot(alphaRange, psnrScores, '-o','LineWidth',1.5);
    %ylabel('PSNR (dB)');
    %yyaxis right
    %plot(alphaRange, ssimScores, '-s','LineWidth',1.5);
    %ylabel('SSIM');
    %xlabel('Varpi'); title('PSNR + SSIM vs Varpi');
    %grid on; legend('PSNR','SSIM');
end

% --- Create LaTeX longtable with only best alpha results ---
fid1 = fopen('best_results_table.tex','w');
fprintf(fid1, '\\begin{longtable}{|c|c|c|c|c|}\n');
fprintf(fid1, '\\caption{Best varpi Prediction per Brain CT Image of Experimental Result 2 (Total Images: %d)} \\\\ \n', numImages);
fprintf(fid1, '\\hline\n');
fprintf(fid1, '\\textbf{Image} & \\textbf{Best varpi (PSNR)} & \\textbf{PSNR (dB)} & \\textbf{Best varpi (SSIM)} & \\textbf{SSIM} \\\\\n\\hline\n');
fprintf(fid1, '\\endfirsthead\n');
fprintf(fid1, '\\hline\n');
fprintf(fid1, '\\textbf{Image} & \\textbf{Best varpi (PSNR)} & \\textbf{PSNR (dB)} & \\textbf{Best varpi (SSIM)} & \\textbf{SSIM} \\\\\n\\hline\n');
fprintf(fid1, '\\endhead\n');
fprintf(fid1, '\\hline\n\\endfoot\n');   % <-- ensures bottom line on every page
fprintf(fid1, '\\hline\n\\endlastfoot\n'); % <-- ensures bottom line on last page

for k = 1:numImages
    fprintf(fid1, '%s & %s & %.4f & %s & %.4f \\\\\n', ...
        imageFiles(k).name, bestAlphaPSNR{k}, bestPSNR(k), bestAlphaSSIM{k}, bestSSIM(k));
end

% --- Compute overall ranges ---
psnrMin = min(bestPSNR);
psnrMax = max(bestPSNR);
ssimMin = min(bestSSIM);
ssimMax = max(bestSSIM);

% --- Add summary row ---
fprintf(fid1, '\\hline\n');
fprintf(fid1, 'Overall Range & -- & %.4f--%.4f & -- & %.4f--%.4f \\\\\n', ...
    psnrMin, psnrMax, ssimMin, ssimMax);

fprintf(fid1, '\\hline\n\\end{longtable}\n');
fclose(fid1);

disp('LaTeX longtable saved as best_results_table.tex');

% --- Create separate LaTeX file for literature prediction ---
fid22 = fopen('literature_comparisonexp2.tex','w');

fprintf(fid22, '\\begin{table}[ht]\n');
fprintf(fid22, '\\centering\n');
fprintf(fid22, '\\caption{Comparison of Reported PSNR and SSIM in Published CT Enhancement Models with Experimental Result 2}\n');
fprintf(fid22, '\\begin{tabular}{|c|c|c|c|}\n');
fprintf(fid22, '\\hline\n');
fprintf(fid22, '\\textbf{Model / Method} & \\textbf{Application} & \\textbf{PSNR (dB)} & \\textbf{SSIM} \\\\\n');
fprintf(fid22, '\\hline\n');

% ✅ Your method row now uses actual computed ranges
fprintf(fid22, 'Proposed MRFC Method (Best $\\varpi$) & CT brain image enhancement & %.2f--%.2f & %.2f--%.2f \\\\\n', ...
    psnrMin, psnrMax, ssimMin, ssimMax);

% Published methods
fprintf(fid22, 'CNN-based Denoising (DnCNN, 2023) & Low-dose CT denoising & 32--36 & 0.90--0.94 \\\\\n');
fprintf(fid22, 'U-Net (2024) & CT reconstruction & 30--36 & 0.91--0.94 \\\\\n');
fprintf(fid22, 'SRGAN (2022) & CT resolution enhancement & 30--34 & 0.88--0.92 \\\\\n');
fprintf(fid22, 'Hybrid CNN + Wavelet (2021) & CT brain image enhancement & 33--37 & 0.91--0.95 \\\\\n');
fprintf(fid22, 'BM3D Filtering & CT denoising & 29--33 & 0.87--0.91 \\\\\n');
fprintf(fid22, 'ResNet (2024) & CT reconstruction & 34--38 & 0.92--0.96 \\\\\n');
fprintf(fid22, 'Non-Local Means (NLM) Filtering & Noise reduction & 28--32 & 0.85--0.90 \\\\\n');

fprintf(fid22, '\\hline\n');
fprintf(fid22, '\\end{tabular}\n');
fprintf(fid22, '\\end{table}\n');

fclose(fid22);

disp('Updated literature_comparisonexp2.tex with Your Method  and published methods.');