%% Highest PSNR + SSIM Evaluation with Combined Display + Matrix Export
% Author: Nalliah
% Purpose: Display highest PSNR and SSIM cases with input image, enhanced image,
% PSNR+SSIM plots, and corresponding filter matrix M. Export results to LaTeX
% with mean ± standard deviation included.

clc; clear; close all;

% --- Folder containing CT images ---
imageFolder = 'C:\Users\Dell\Desktop\Scientific report paper\SCIENTIFIC REPORT_PAPER\matlab code-\brain data set\no'; 
imageFiles = dir(fullfile(imageFolder, '*.jpg'));  % or '*.png' / '*.dcm'

% --- Count number of images ---
numImages = length(imageFiles);
fprintf('Number of images found in folder: %d\n\n', numImages);

% --- Alpha range and parameters ---
alphaRange = 0.71 : 0.01 : 0.95;
u = 0.1; p = 2.8; w = 1; r = 0.8;

% --- Storage ---
bestAlphaPSNR = cell(numImages,1);
bestPSNR = zeros(numImages,1);
bestAlphaSSIM = cell(numImages,1);
bestSSIM = zeros(numImages,1);
bestMatrixPSNR = cell(numImages,1);
bestMatrixSSIM = cell(numImages,1);

% --- Loop over all images ---
for k = 1:numImages
    % Load baseline CT image
    fileName = fullfile(imageFolder, imageFiles(k).name);
    I1 = imread(fileName);
    if size(I1,3) == 3, I1 = rgb2gray(I1); end
    I1 = im2double(I1);

    % Storage for scores
    psnrScores = zeros(size(alphaRange));
    ssimScores = zeros(size(alphaRange));
    matrices = cell(length(alphaRange),1);

    % --- Loop over alpha values ---
    for i = 1:length(alphaRange)
        a = alphaRange(i);

        % Build filter kernel
        A = zeros(1,9);
        for n = 1:9
            V = (p^(n-1) * gamma(u + 1)) / gamma(u + n);
            a1 = ((1 - a) * w) / ((1 + r * (n - 1)) * V);
            A(n) = round(a1, 6);
        end
        M = reshape(A, 3, 3);
        matrices{i} = M;

        % Apply filter
        filteredImage = imfilter(I1, M, 'replicate');

        % Compute PSNR and SSIM vs original
        psnrScores(i) = psnr(filteredImage, I1);
        [ssimScores(i), ~] = ssim(filteredImage, I1);
    end

    % --- Best alpha for this image ---
    [~, idxPSNR] = max(psnrScores);
    [~, idxSSIM] = max(ssimScores);

    bestAlphaPSNR{k} = sprintf('%.2f', alphaRange(idxPSNR));
    bestPSNR(k) = psnrScores(idxPSNR);
    bestMatrixPSNR{k} = matrices{idxPSNR};

    bestAlphaSSIM{k} = sprintf('%.2f', alphaRange(idxSSIM));
    bestSSIM(k) = ssimScores(idxSSIM);
    bestMatrixSSIM{k} = matrices{idxSSIM};
end

% --- Find overall highest PSNR and SSIM ---
[overallBestPSNR, idxBestPSNR] = max(bestPSNR);
[overallBestSSIM, idxBestSSIM] = max(bestSSIM);

% --- Compute Mean ± Standard Deviation across dataset ---
meanPSNR = mean(bestPSNR);
stdPSNR  = std(bestPSNR);
meanSSIM = mean(bestSSIM);
stdSSIM  = std(bestSSIM);

fprintf('PSNR (mean ± SD): %.4f ± %.4f dB\n', meanPSNR, stdPSNR);
fprintf('SSIM (mean ± SD): %.4f ± %.4f\n', meanSSIM, stdSSIM);

%% --- Export to LaTeX file with extra column ---
outFile = 'best_cases_mean_sd.tex';
fid = fopen(outFile, 'w');
fprintf(fid, '\\begin{table}[ht]\\n');
fprintf(fid, '\\centering\\n');
fprintf(fid, '\\caption{Highest PSNR and SSIM Cases with Corresponding Matrix $M$ and Mean $\\pm$ SD}\\n');
fprintf(fid, '\\begin{tabular}{|c|c|c|c|c|}\\n');
fprintf(fid, '\\hline\\n');
fprintf(fid, '\\textbf{Case} & \\textbf{Image} & \\textbf{Best $\\alpha$} & \\textbf{Matrix $M$ (3x3)} & \\textbf{Mean $\\pm$ SD} \\\\\\n');
fprintf(fid, '\\hline\\n');

% PSNR case
Mpsnr = bestMatrixPSNR{idxBestPSNR};
fprintf(fid, 'Highest PSNR (%.4f dB) & %s & %s & ', overallBestPSNR, imageFiles(idxBestPSNR).name, bestAlphaPSNR{idxBestPSNR});
fprintf(fid, '$\\begin{bmatrix} %.4f & %.4f & %.4f \\\\ %.4f & %.4f & %.4f \\\\ %.4f & %.4f & %.4f \\end{bmatrix}$ & ', ...
    Mpsnr(1,1), Mpsnr(1,2), Mpsnr(1,3), Mpsnr(2,1), Mpsnr(2,2), Mpsnr(2,3), Mpsnr(3,1), Mpsnr(3,2), Mpsnr(3,3));
fprintf(fid, '%.4f $\\pm$ %.4f dB \\\\\\n', meanPSNR, stdPSNR);

% SSIM case
Mssim = bestMatrixSSIM{idxBestSSIM};
fprintf(fid, 'Highest SSIM (%.4f) & %s & %s & ', overallBestSSIM, imageFiles(idxBestSSIM).name, bestAlphaSSIM{idxBestSSIM});
fprintf(fid, '$\\begin{bmatrix} %.4f & %.4f & %.4f \\\\ %.4f & %.4f & %.4f \\\\ %.4f & %.4f & %.4f \\end{bmatrix}$ & ', ...
    Mssim(1,1), Mssim(1,2), Mssim(1,3), Mssim(2,1), Mssim(2,2), Mssim(2,3), Mssim(3,1), Mssim(3,2), Mssim(3,3));
fprintf(fid, '%.4f $\\pm$ %.4f \\\\\\n', meanSSIM, stdSSIM);

fprintf(fid, '\\hline\\n');
fprintf(fid, '\\end{tabular}\\n');
fprintf(fid, '\\end{table}\\n');
fclose(fid);

disp(['LaTeX file saved as ', outFile, ' with highest PSNR/SSIM cases, matrices, and mean ± SD column.']);