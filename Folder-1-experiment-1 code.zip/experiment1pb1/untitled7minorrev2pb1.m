%% SSIM + PSNR Evaluation for Brain CT Images (Stage-wise Export into Separate Folders)
% Author: Nalliah
% Purpose:
% - Loads all CT images from 'no' folder
% - Computes PSNR + SSIM across alpha values
% - Enhances images stage-wise using mathematical kernel
% - Saves original + all alpha-stage enhanced images into separate subfolders
%   inside one main folder (AllAlphaEnhancedImages)

clc; clear; close all;

% --- Folder containing CT images ---
imageFolder = 'C:\Users\Dell\Desktop\Scientific report paper\SCIENTIFIC REPORT_PAPER\minor revision response\minorrev2pb1\no';
imageFiles = dir(fullfile(imageFolder, '*.jpg'));  % or '*.png' / '*.dcm'

% --- Count number of images ---
numImages = length(imageFiles);
fprintf('Number of images found in folder: %d\n\n', numImages);

% --- Alpha range and parameters ---
alphaRange = 0.71 : 0.01 : 0.95;
u = 0.1; p = 2.8; w = 1; r = 0.8;

% --- Main output folder ---
mainOutputFolder = fullfile(pwd, 'AllAlphaEnhancedImages');
if ~exist(mainOutputFolder, 'dir'), mkdir(mainOutputFolder); end

% --- Loop over all images ---
for k = 1:numImages
    % Load baseline CT image
    fileName = fullfile(imageFolder, imageFiles(k).name);
    I1 = imread(fileName);
    if size(I1,3) == 3, I1 = rgb2gray(I1); end
    I1 = im2double(I1);

    % --- Create subfolder for this image ---
    [~, baseName, ~] = fileparts(imageFiles(k).name);
    subFolder = fullfile(mainOutputFolder, baseName);
    if ~exist(subFolder, 'dir'), mkdir(subFolder); end

    % --- Save original image into subfolder ---
    origOutName = fullfile(subFolder, ['orig_' imageFiles(k).name]);
    imwrite(I1, origOutName);

    % Storage for scores
    psnrScores = zeros(size(alphaRange));
    ssimScores = zeros(size(alphaRange));

    % --- Loop over alpha values ---
    for i = 1:length(alphaRange)
        a = alphaRange(i);

        % Build filter kernel
        A = zeros(1,9);
        for n = 1:9
            V = (p^(n-1) * gamma(u + 1)) / gamma(u + n);
            a1 = ((1 - a) * w) / ((1 + r * (n - 1)) * V);
            A(n) = round(a1, 6);
        end
        M = reshape(A, 3, 3);

        % Apply filter
        filteredImage = imfilter(I1, M, 'replicate');

        % Compute PSNR and SSIM vs original
        psnrScores(i) = psnr(filteredImage, I1);
        [ssimScores(i), ~] = ssim(filteredImage, I1);

        % --- Save enhanced image for this alpha into subfolder ---
        enhOutName = fullfile(subFolder, ...
            [sprintf('alpha_%.2f_', a) imageFiles(k).name]);
        imwrite(filteredImage, enhOutName);
    end

    % --- Report best alpha for this image ---
    [~, idxPSNR] = max(psnrScores);
   % [~, idxSSIM] = max(ssimScores);
    fprintf('Image: %s | Best Alpha (PSNR) = %.2f | PSNR = %.4f dB\n', ...
        imageFiles(k).name, alphaRange(idxPSNR), psnrScores(idxPSNR));
    %fprintf('Image: %s | Best Alpha (SSIM) = %.2f | SSIM = %.4f\n', ...
     %   imageFiles(k).name, alphaRange(idxSSIM), ssimScores(idxSSIM));
end

disp('Original + all alpha-stage enhanced images saved into separate subfolders inside AllAlphaEnhancedImages.');