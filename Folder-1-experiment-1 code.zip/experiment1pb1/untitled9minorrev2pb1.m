%% PSNR Evaluation for Best Alpha Enhanced Images (LaTeX Export with Mean & Std)
% Author: Nalliah
% Purpose:
% - Scan each subfolder inside AllAlphaEnhancedImages
% - Detect the original image and the best alpha enhanced image
% - Compute PSNR(original, best-enhanced)
% - Save results into a LaTeX table file including mean and std

clc; clear; close all;

% --- Main folder containing subfolders ---
mainFolder = fullfile(pwd, 'AllAlphaEnhancedImages');

% --- Summary folder containing best alpha enhanced images ---
bestFolder = fullfile(pwd, 'BestAlphaEnhancedImages');
if ~exist(bestFolder, 'dir'), mkdir(bestFolder); end

% --- Get list of subfolders ---
subFolders = dir(mainFolder);
subFolders = subFolders([subFolders.isdir]); 
subFolders = subFolders(~ismember({subFolders.name},{'.','..'}));

% --- Storage for LaTeX table ---
results = {};
psnrAll = [];

for s = 1:length(subFolders)
    thisFolder = fullfile(mainFolder, subFolders(s).name);

    % --- Find original image ---
    origFile = dir(fullfile(thisFolder, 'orig_*.jpg'));
    if isempty(origFile)
        warning('No original image found in %s', thisFolder);
        continue;
    end
    Iorig = imread(fullfile(thisFolder, origFile(1).name));
    if size(Iorig,3)==3, Iorig = rgb2gray(Iorig); end
    Iorig = im2double(Iorig);

    % --- Find enhanced images ---
    enhFiles = dir(fullfile(thisFolder, 'alpha_*.jpg'));
    if isempty(enhFiles)
        warning('No enhanced images found in %s', thisFolder);
        continue;
    end

    psnrVals = zeros(length(enhFiles),1);
    for k = 1:length(enhFiles)
        Ienh = imread(fullfile(thisFolder, enhFiles(k).name));
        if size(Ienh,3)==3, Ienh = rgb2gray(Ienh); end
        Ienh = im2double(Ienh);
        if ~isequal(size(Ienh),size(Iorig)), Ienh = imresize(Ienh,size(Iorig)); end
        psnrVals(k) = psnr(Ienh,Iorig);
    end

    [maxPSNR, idxBest] = max(psnrVals);
    bestImage = enhFiles(idxBest).name;

    % --- Copy best image into summary folder ---
    copyfile(fullfile(thisFolder, bestImage), ...
             fullfile(bestFolder, [subFolders(s).name '_best.jpg']));

    % --- Store results ---
    results{end+1,1} = subFolders(s).name;
    results{end,2}   = bestImage;
    results{end,3}   = sprintf('%.4f', maxPSNR);

    psnrAll(end+1) = maxPSNR;

    fprintf('Folder: %s | Best Image: %s | PSNR = %.4f dB\n', ...
        subFolders(s).name, bestImage, maxPSNR);
end

%% --- Compute overall mean and std ---
meanPSNR = mean(psnrAll);
stdPSNR  = std(psnrAll);

%% --- Save LaTeX Table ---
fid = fopen('best_alpha_summary.tex','w');
fprintf(fid, '\\begin{table}[htbp]\n');
fprintf(fid, '\\centering\n');
fprintf(fid, '\\caption{Best Alpha Enhanced Images with PSNR Values}\n');
fprintf(fid, '\\label{tab:best_alpha}\n');
fprintf(fid, '\\begin{tabular}{|c|c|c|}\n');
fprintf(fid, '\\hline\n');
fprintf(fid, '\\textbf{Folder} & \\textbf{Best Image} & \\textbf{PSNR (dB)} \\\\ \\hline\n');

for i = 1:size(results,1)
    fprintf(fid, '%s & %s & %s \\\\ \\hline\n', ...
        results{i,1}, results{i,2}, results{i,3});
end

% Add mean and std rows
fprintf(fid, '\\textbf{Mean} & -- & %.4f \\\\ \\hline\n', meanPSNR);
fprintf(fid, '\\textbf{Std Dev} & -- & %.4f \\\\ \\hline\n', stdPSNR);

fprintf(fid, '\\end{tabular}\n');
fprintf(fid, '\\end{table}\n');
fclose(fid);

disp('LaTeX table saved as best_alpha_summary.tex with PSNR values, mean, and std.');