%% PSNR Evaluation Across Enhanced_Results Subfolders
% Author: Nalliah
% Purpose: Automatically detect original CT image in each subfolder,
% compute PSNR for all enhanced images, identify the best alpha enhanced image,
% compute its PSNR relative to the original, list results in LaTeX format,
% and calculate mean ± SD across all best PSNR values.

clc; clear; close all;

% Top-level folder containing all subfolders
mainFolder = 'C:\Users\Dell\Desktop\Scientific report paper\SCIENTIFIC REPORT_PAPER\minor revision response\minorrev2pb1\AllAlphaEnhancedImages';

% Folder to store best images
outputFolder = fullfile(mainFolder, 'Best_Enhanced_Results');
if ~exist(outputFolder, 'dir')
    mkdir(outputFolder);
end

% Get list of subfolders
subFolders = dir(mainFolder);
subFolders = subFolders([subFolders.isdir]); 
subFolders = subFolders(~ismember({subFolders.name},{'.','..','Best_Enhanced_Results'}));

bestPSNRs = [];   % store best PSNR from each subfolder
bestImages = {};  % store best image filename
bestFolders = {}; % store folder names

for s = 1:length(subFolders)
    thisFolder = fullfile(mainFolder, subFolders(s).name);
    fprintf('\nProcessing Folder: %s\n', subFolders(s).name);

    % Detect original image automatically (match "orig_" prefix)
    origFiles = dir(fullfile(thisFolder, 'orig_*.*'));
    if isempty(origFiles)
        warning('No original image found in folder: %s', thisFolder);
        continue;
    end
    originalFile = fullfile(thisFolder, origFiles(1).name);
    Iorig = imread(originalFile);
    if size(Iorig,3)==3, Iorig = rgb2gray(Iorig); end
    Iorig = im2double(Iorig);

    % Get enhanced images (exclude original)
    imageFiles = [dir(fullfile(thisFolder,'*.jpg')); ...
                  dir(fullfile(thisFolder,'*.png')); ...
                  dir(fullfile(thisFolder,'*.jpeg'))];
    imageFiles = imageFiles(~ismember({imageFiles.name},{origFiles(1).name}));

    allPSNR = [];
    fileNames = {};
    for k=1:length(imageFiles)
        Ienh = imread(fullfile(thisFolder,imageFiles(k).name));
        if size(Ienh,3)==3, Ienh = rgb2gray(Ienh); end
        Ienh = im2double(Ienh);
        if ~isequal(size(Ienh),size(Iorig)), Ienh = imresize(Ienh,size(Iorig)); end
        psnrVal = psnr(Ienh,Iorig);
        fprintf('Enhanced Image: %s | PSNR = %.4f dB\n', imageFiles(k).name, psnrVal);
        allPSNR(end+1) = psnrVal;
        fileNames{end+1} = imageFiles(k).name;
    end

    % Find best enhanced image in this folder
    if ~isempty(allPSNR)
        [maxPSNR, idx] = max(allPSNR);
        bestImage = fileNames{idx};
        fprintf('Best Enhanced Image (%s): %s | PSNR(original,best) = %.4f dB\n', ...
            subFolders(s).name, bestImage, maxPSNR);

        % Collect results
        bestPSNRs(end+1) = maxPSNR;
        bestImages{end+1} = bestImage;
        bestFolders{end+1} = subFolders(s).name;

        % Save best image into output folder
        Ibest = imread(fullfile(thisFolder, bestImage));
        [~,~,ext] = fileparts(bestImage);
        outName = sprintf('%s_best%s', subFolders(s).name, ext);
        imwrite(Ibest, fullfile(outputFolder, outName));
    end
end

%% ================= ENHANCED_RESULTS SUMMARY =================
if ~isempty(bestPSNRs)
    meanBestPSNR = mean(bestPSNRs);
    stdBestPSNR  = std(bestPSNRs);

    fprintf('\nEnhanced_Results Summary:\n');
    for i = 1:length(bestPSNRs)
        fprintf('Best Image (%s): %s | PSNR(original,best) = %.4f dB\n', ...
            bestFolders{i}, bestImages{i}, bestPSNRs(i));
    end

    fprintf('\nEnhanced_Results: Mean PSNR of Best Enhanced Images = %.4f dB\n', meanBestPSNR);
    fprintf('Enhanced_Results: Std Dev of Best Enhanced Images   = %.4f dB\n', stdBestPSNR);

    %% ================= SAVE LATEX TABLE TO FILE =================
    texFile = fullfile(mainFolder, 'Enhanced_Results_Summary.tex');
    fid = fopen(texFile, 'w');

    fprintf(fid,'\\documentclass{article}\n');
    fprintf(fid,'\\usepackage{graphicx}\n');
    fprintf(fid,'\\begin{document}\n');
    fprintf(fid,'\\begin{table}[htbp]\n');
    fprintf(fid,'\\centering\n');
    fprintf(fid,'\\caption{Summary of Best Enhanced Images PSNR Values (Original vs Best)}\n');
    fprintf(fid,'\\label{tab:best_psnr}\n');
    fprintf(fid,'\\begin{tabular}{|c|c|c|}\n');
    fprintf(fid,'\\hline\n');
    fprintf(fid,'\\textbf{Folder} & \\textbf{Best Image} & \\textbf{PSNR (dB)} \\\\ \\hline\n');

    % Escape underscores and fix spacing automatically
    for i = 1:length(bestPSNRs)
        folderName = strrep(bestFolders{i}, '_', '\\_');
        imageName  = strrep(bestImages{i}, '_', '\\_');
        fprintf(fid,'%s & %s & %.2f \\\\ \\hline\n', folderName, imageName, bestPSNRs(i));
    end

    fprintf(fid,'\\textbf{Mean} & -- & %.2f \\\\ \\hline\n', meanBestPSNR);
    fprintf(fid,'\\textbf{Std Dev} & -- & %.2f \\\\ \\hline\n', stdBestPSNR);
    fprintf(fid,'\\end{tabular}\n');
    fprintf(fid,'\\end{table}\n');
    fprintf(fid,'\\end{document}\n');
    fclose(fid);

    fprintf('\nLaTeX table saved to: %s\n', texFile);

else
    fprintf('\nNo enhanced images found in any subfolder.\n');
end